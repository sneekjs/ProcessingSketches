# Box2D for Processing

A Processing library wrapping JBox2D (http://www.jbox2d.org/).

Download library: http://www.shiffman.net/p5/libraries/box2d_processing/box2d_processing.zip

Tutorial and further examples for this library are avaiable in The Nature of Code book: http://natureofcode.com.
